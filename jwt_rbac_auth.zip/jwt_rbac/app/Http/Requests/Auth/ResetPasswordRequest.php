<?php declare(strict_types=1);
namespace App\Http\Requests\Auth;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;
class ResetPasswordRequest extends FormRequest {
    public function authorize(): bool { return true; }
    public function rules(): array {
        return ['token'=>['required','string','size:64'],'email'=>['required','email:rfc','max:255'],'password'=>['required','confirmed',Password::min(8)->letters()->mixedCase()->numbers()->symbols()->uncompromised(3)]];
    }
}
