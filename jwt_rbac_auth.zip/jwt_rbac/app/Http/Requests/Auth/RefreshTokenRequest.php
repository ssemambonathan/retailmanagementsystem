<?php declare(strict_types=1);
namespace App\Http\Requests\Auth;
use Illuminate\Foundation\Http\FormRequest;
class RefreshTokenRequest extends FormRequest {
    public function authorize(): bool { return true; }
    public function rules(): array { return ['refresh_token'=>['required','string','min:32','max:128']]; }
}
